﻿namespace GenericDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ListOfString names = new ListOfString();
            names.Add("Brights");
            names.Add("Academic Work");
            names.Add("ACME LTD");

            string name = names[1];
            names[1] = "Academic Work Sweden AB";

            PrintElements(names);

            names.Sort();

            foreach (string item in names)
            {
                Console.WriteLine(item);
            }
        }

        private static void PrintElements(ListOfString names)
        {
            for (int i = 0; i < names.Count; i++)
            {
                Console.WriteLine(names[i]);
            }

            Console.WriteLine("-----------------------");
        }

    }
}